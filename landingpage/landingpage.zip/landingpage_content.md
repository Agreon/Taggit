Extract Data from you documents

Automated Learning

Combine writing with Tagging

Tag your documents!

Automatically Extract Tags from your documents 

Learn with the help of tags

Create Projects

Show only the things you need
